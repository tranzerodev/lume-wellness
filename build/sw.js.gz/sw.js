var __wpo = {
  "assets": {
    "main": [
      "/8e4a6dcc692b3887f9f542cd6894d6d4.eot",
      "/3486d77c092faece78d767e9f5225db5.eot",
      "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
      "/f233a55ad8b67a5a2a19200ab160146f.jpg",
      "/b373455ed09074eb878735cbf98f2318.png",
      "/ada13e03371695e01a4d32624e68500c.png",
      "/ced611daf7709cc778da928fec876475.eot",
      "/333bae208dc363746961b234ff6c2500.woff",
      "/d41f55a78e6f49a5512878df1737e58a.ttf",
      "/d7d5bf239198d99fb34f6a5d9589eba7.woff2",
      "/d8532f5848e13f03edd135b52b69236e.png",
      "/d05db6a1e0bf0431df77964a3d87c8e2.eot",
      "/06147b6cd88c7346cecd1edd060cd5de.ttf",
      "/467c713a5f0a5ed1f60e428522836858.ttf",
      "/9bee5a6bf6ad711f28d584c1537d5505.jpg",
      "/7f883109e04af520c1b93151278a1bc4.png",
      "/bca86ffe040b5377d8f66d583b37c14a.ttf",
      "/c7c112bb479ff14b11d8cf44c17433ce.png",
      "/dfe6880ccfc7f4182c5db0783cc855d0.png",
      "/fdfd0b5ba9724dac11c309cbf313e417.png",
      "/454bc9827a7d649e9f69719db4c6a717.jpg",
      "/f8f6fc2846c3419cc7ab545ab19dd15d.woff2",
      "/5063b105c7646c8043d58c5289f02cca.eot",
      "/c4f508e7c4f01a9eeba7f08155cde04e.woff",
      "/3ace94a690999e4268a0bb721d667efc.png",
      "/0bff33a5fd7ec390235476b4859747a0.ttf",
      "/c2801fb415f03c7b170934769d7b5397.svg",
      "/7b9568e6389b1f8ae0902cd39665fc1e.svg",
      "/4e61d84d5fdac5c7147472b3d87f132f.woff",
      "/df747564f131011aadfd1580d01eb3f7.woff",
      "/8fd3bb46c064c6ef462d5da3525ad735.jpg",
      "/3a809352fd61292e385110d0171ddf32.png",
      "/44d537ab79f921fde5a28b2c1636f397.woff2",
      "/f5f2566b93e89391da4db79462b8078b.woff2",
      "/fe6e40fcdc0526534eb3a7688fd7d2f6.png",
      "/c1a866ec0e04a5e1915b41fcf261457c.eot",
      "/favicon.ico",
      "/65b286af947c0d982ca01b40e1fcab38.ttf",
      "/8d746c60aa66a3dc03344a10d30401f6.jpg",
      "/a9c4bb7348f42626454c988dbde1d0a0.svg",
      "/cccc9d29470e879e40eb70249d9a2705.woff2",
      "/c5e0f14f88a828261ba01558ce2bf26f.woff",
      "/a85d3d4992fc4c0648b17c6e82e15575.png",
      "/runtime.832ef90295f1aab1fa2d.js",
      "/"
    ],
    "additional": [
      "/npm.webpack.236f442153b9af7f5d1c.chunk.js",
      "/npm.lodash.339ba4b5e8183a9d53c0.chunk.js",
      "/npm.react-fast-compare.ea32a4c32b02800f5a3b.chunk.js",
      "/npm.react-helmet.e5da5e38bb5d93ec035f.chunk.js",
      "/npm.intl.322ea77011d5e7e0553b.chunk.js",
      "/npm.react-toastify.8d7fa9125dccc1d9608f.chunk.js",
      "/npm.redux-saga.75f6969a4caeb99716a0.chunk.js",
      "/main.a5c2ab7d3711dd22764f.chunk.js",
      "/npm.axios.a3df6a72330198549365.chunk.js",
      "/npm.core-js.71c113b02ceb7bc4da96.chunk.js",
      "/npm.dom-helpers.babe0d4a7d008d258d19.chunk.js",
      "/npm.fortawesome.c18f018980fced83b45c.chunk.js",
      "/npm.react-app-polyfill.0b0dd3be66dc3c441e78.chunk.js",
      "/npm.react-bootstrap.f47fd53f0520807d8c89.chunk.js",
      "/npm.react-datepicker.0fb38e955dadeb668897.chunk.js",
      "/npm.react-id-generator.e23f0dbd519f49582b6b.chunk.js",
      "/npm.react-onclickoutside.4a55970fc33ecafc27cb.chunk.js",
      "/18.0313b0847a946d025ae1.chunk.js",
      "/19.3f23dc020ad15ccb965e.chunk.js",
      "/20.4911206398a00d78de4c.chunk.js",
      "/21.93f7b5a2d688388be923.chunk.js",
      "/22.c16bc005ce979d7e66d7.chunk.js",
      "/23.185506a2eb3a1f384941.chunk.js",
      "/24.1f532e142215193680fe.chunk.js",
      "/25.46883cc2434044405cc7.chunk.js",
      "/26.a5baca776ce2fe3eb5f1.chunk.js",
      "/27.4da248478b48fcba6eb3.chunk.js",
      "/28.57c1f65bfa1993eb648c.chunk.js",
      "/29.d36a532271b331ece86d.chunk.js",
      "/30.0930857294077f3ddbf4.chunk.js",
      "/31.0056c8525b7f2c20f109.chunk.js",
      "/32.bffc7316aaccb8950318.chunk.js",
      "/33.660b475a59cf6ae32a5c.chunk.js",
      "/34.5852dc305050ced6bc23.chunk.js",
      "/35.60e3c3586f5307c35b9e.chunk.js",
      "/36.5e2cae6657695965ac06.chunk.js",
      "/37.ac19e3596164eb3729fd.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "340ee70e87850176047733192ea8109dd6380082": "/8e4a6dcc692b3887f9f542cd6894d6d4.eot",
    "14fdd45a3501c3283a950d583018a7228ae7030b": "/3486d77c092faece78d767e9f5225db5.eot",
    "af91c12f0f406a4f801aeb3b398768fe41d8f864": "/b7c9e1e479de3b53f1e4e30ebac2403a.woff",
    "b17b53abad25e6f819e1e7f69e330d337cbe5381": "/f233a55ad8b67a5a2a19200ab160146f.jpg",
    "a4986f08fa3179d251c5de45255aeff1bf30b1fb": "/b373455ed09074eb878735cbf98f2318.png",
    "63cf32e5616c15f4ed32a43d1b9b3381a2bdc6a3": "/ada13e03371695e01a4d32624e68500c.png",
    "2dff0768f4c0a53228761eab917e2c65556042d4": "/ced611daf7709cc778da928fec876475.eot",
    "43dae5c2482bfb5d04d896529600eb621181103a": "/333bae208dc363746961b234ff6c2500.woff",
    "3331eebdd4ba348ef25abe00c39ffbe867d46575": "/d41f55a78e6f49a5512878df1737e58a.ttf",
    "b6a366a6c158b5f43ac810a8979f25d117a443c9": "/d7d5bf239198d99fb34f6a5d9589eba7.woff2",
    "37aeb2b28e43012bd872163962c8d276f371645b": "/d8532f5848e13f03edd135b52b69236e.png",
    "2ce898899afaf3891cac3d96a8e81fd546c79aaa": "/d05db6a1e0bf0431df77964a3d87c8e2.eot",
    "c5a1a93f668d15f55deac38b4728f8d901bd4748": "/06147b6cd88c7346cecd1edd060cd5de.ttf",
    "ed3b0e43bc19d415a65d63cbcbb5a495a8417668": "/467c713a5f0a5ed1f60e428522836858.ttf",
    "bc7cd3e8a97a9a2e660db375c8fa00e6332bea7a": "/9bee5a6bf6ad711f28d584c1537d5505.jpg",
    "8786e18863ecb0388db22e572f4152a6eb971d7a": "/7f883109e04af520c1b93151278a1bc4.png",
    "4e9db546a9c05415648baa33ed30bd8583edff0c": "/bca86ffe040b5377d8f66d583b37c14a.ttf",
    "5760c54ed55c118067d09314c4a3500e7fc828f4": "/c7c112bb479ff14b11d8cf44c17433ce.png",
    "f512e0f85b59dda71c5db8c2e7d8a6aef5afeb1a": "/dfe6880ccfc7f4182c5db0783cc855d0.png",
    "1b92ac2f45a75abc96bc7f53d7d435d738934b43": "/fdfd0b5ba9724dac11c309cbf313e417.png",
    "6905fdcd42433f5b4a0fe483ec2bdb44caa97a4e": "/454bc9827a7d649e9f69719db4c6a717.jpg",
    "f35fe6e6c26ce8d8f71cb94ce11f47392fb50f2b": "/f8f6fc2846c3419cc7ab545ab19dd15d.woff2",
    "7ed86fe71d4dc31d5edf492f7472d6fb88c3c3c9": "/5063b105c7646c8043d58c5289f02cca.eot",
    "7626840dab0e2ae37b2d16572a6f183a71a0dd73": "/c4f508e7c4f01a9eeba7f08155cde04e.woff",
    "4820d010e7a4c020e631b929a844ce701f7c44ce": "/3ace94a690999e4268a0bb721d667efc.png",
    "40d9789010f6137e543e4d97025b867707d2f425": "/0bff33a5fd7ec390235476b4859747a0.ttf",
    "55a9f6dd285c88c6c9847fee0d5ce127c4c61c52": "/c2801fb415f03c7b170934769d7b5397.svg",
    "dd1b42f8776d9b48adda30b0069aa0e5f18989d3": "/7b9568e6389b1f8ae0902cd39665fc1e.svg",
    "0c1d8713c98dc67c895b3b2cdb7ac3f40203d69d": "/4e61d84d5fdac5c7147472b3d87f132f.woff",
    "14ae3dcec4beb36063e29e6c0a7e30ed56fdca27": "/df747564f131011aadfd1580d01eb3f7.woff",
    "d49e03e991f4013977f18979e1ec9423ac41e846": "/8fd3bb46c064c6ef462d5da3525ad735.jpg",
    "6a23a06f9e6822f127dc59fafc9c50549f9cf151": "/3a809352fd61292e385110d0171ddf32.png",
    "b2879f9e1d0985a96842bf7f55a2b2cc4c636d04": "/44d537ab79f921fde5a28b2c1636f397.woff2",
    "be142af0f56062f6e864de121b98054c7b5954fd": "/f5f2566b93e89391da4db79462b8078b.woff2",
    "836fec09cb712ef515b5a8f377771cbd43c4207a": "/fe6e40fcdc0526534eb3a7688fd7d2f6.png",
    "1115185386ada5846eecc4e2e1f076ca7617e0cd": "/c1a866ec0e04a5e1915b41fcf261457c.eot",
    "7b4d86afc7681b7ad2602dc490676d134987bc08": "/favicon.ico",
    "5d5375ce3ae5b500df039da009ccdaca29d52fc0": "/65b286af947c0d982ca01b40e1fcab38.ttf",
    "18c732f09295a50005c77e79e2a866cf799039b7": "/8d746c60aa66a3dc03344a10d30401f6.jpg",
    "3e9abaae5dc647f4019a4dcdde1b51f14c2054e8": "/a9c4bb7348f42626454c988dbde1d0a0.svg",
    "5fe986cda635681b4b6bbd6111df2f26d7fca286": "/cccc9d29470e879e40eb70249d9a2705.woff2",
    "6900998c1d878e73b2f9ac3a9a9746365d49a54f": "/c5e0f14f88a828261ba01558ce2bf26f.woff",
    "fddf69e7c30d420c0ddf460d73ce970b7c223fc3": "/a85d3d4992fc4c0648b17c6e82e15575.png",
    "61a83455139529287b5c704d1c2694c52e09bcee": "/npm.webpack.236f442153b9af7f5d1c.chunk.js",
    "223e269ca026aae31a4dbed920e692df589feb70": "/npm.lodash.339ba4b5e8183a9d53c0.chunk.js",
    "776bf9236e12b55d6443b9ec674e6ce72b7fbfa7": "/npm.react-fast-compare.ea32a4c32b02800f5a3b.chunk.js",
    "3876358fb302880196ca7737cba7ed514a25a30f": "/npm.react-helmet.e5da5e38bb5d93ec035f.chunk.js",
    "dbb04ae199fcca114660e939032713f2a8499906": "/npm.intl.322ea77011d5e7e0553b.chunk.js",
    "010adc9ebf866f140f9f0e0a11ba28064eafbce3": "/npm.react-toastify.8d7fa9125dccc1d9608f.chunk.js",
    "920e9453663bf85a418ee9aa0f5843bc09032f59": "/npm.redux-saga.75f6969a4caeb99716a0.chunk.js",
    "ace988178ee6d12663c65b0ed58564d26c8545a8": "/main.a5c2ab7d3711dd22764f.chunk.js",
    "9deba58db62e356344ef65e8ed979154cb82c1fe": "/npm.axios.a3df6a72330198549365.chunk.js",
    "dfa2fff7970181d3c32645efa0a54ac1af7aca10": "/npm.core-js.71c113b02ceb7bc4da96.chunk.js",
    "49e9f1fad29c6b14fa652c4381e2c40cdabe0096": "/npm.dom-helpers.babe0d4a7d008d258d19.chunk.js",
    "5936d29a0273a2edcb66a3fe865a2c5e9db440a2": "/npm.fortawesome.c18f018980fced83b45c.chunk.js",
    "d77831c1b9e184f7c8ecf769f86a392d4672eae6": "/npm.react-app-polyfill.0b0dd3be66dc3c441e78.chunk.js",
    "bf712615539dcd35a9030a26b56fadbe18053e3f": "/npm.react-bootstrap.f47fd53f0520807d8c89.chunk.js",
    "e6cffb39da59a5bcb1b48c9b172e036325c82d4d": "/npm.react-datepicker.0fb38e955dadeb668897.chunk.js",
    "1a1ab4b4dfb0ad644099b4cae8dead3b7d17dd6e": "/npm.react-id-generator.e23f0dbd519f49582b6b.chunk.js",
    "0eb48fec4d0b44c19c614a1467bf6150c7b65976": "/npm.react-onclickoutside.4a55970fc33ecafc27cb.chunk.js",
    "affdb44af02dfa6f28c3e409e269508dc424cfd9": "/runtime.832ef90295f1aab1fa2d.js",
    "753bce366cb750faa98360a120034510c99014a1": "/18.0313b0847a946d025ae1.chunk.js",
    "1731b85ad504e2fab71da4c155b3344592ac1e52": "/19.3f23dc020ad15ccb965e.chunk.js",
    "ab608cd5acc27bf794d780ff6aaf4f1cb7a21d15": "/20.4911206398a00d78de4c.chunk.js",
    "988e8b0850bdaf0e6a4595960d0f75a810be2865": "/21.93f7b5a2d688388be923.chunk.js",
    "6d24e873202e3ab808052097ffa3ed05989584f1": "/22.c16bc005ce979d7e66d7.chunk.js",
    "ed6d83c3ac159b0b9b8a6e7efce796a8162c4e42": "/23.185506a2eb3a1f384941.chunk.js",
    "27b8765cf5d41fd62aa13c660c66fcc8dca37bac": "/24.1f532e142215193680fe.chunk.js",
    "61829ba361130a5ba372b4495fa4ee53c6e8d296": "/25.46883cc2434044405cc7.chunk.js",
    "8600275f376811e0c9ef5a0472b82d8f285611dc": "/26.a5baca776ce2fe3eb5f1.chunk.js",
    "3e737d8fb1117136e23ff85b69098732c8663f61": "/27.4da248478b48fcba6eb3.chunk.js",
    "334ddb7bd5e1a489acff6a66b709d58481e26608": "/28.57c1f65bfa1993eb648c.chunk.js",
    "1faa342bcbf04df325827fa1be0b3da6d697e228": "/29.d36a532271b331ece86d.chunk.js",
    "0857e83918ae7a067353d0ce45389cc56094970b": "/30.0930857294077f3ddbf4.chunk.js",
    "328f7c68f20d2c2dcc65011411adef87499402cb": "/31.0056c8525b7f2c20f109.chunk.js",
    "47328810e5e3e4fe31b98cbda8e8d7d9c3724319": "/32.bffc7316aaccb8950318.chunk.js",
    "c5cfd4a139d0416d7b40bb471bf7a87f36008f43": "/33.660b475a59cf6ae32a5c.chunk.js",
    "bf240bfa792fdf64a0a3ee70429a25a87f445921": "/34.5852dc305050ced6bc23.chunk.js",
    "2daf36495bd9e031bbed2447f16435d1613bef86": "/35.60e3c3586f5307c35b9e.chunk.js",
    "fa09b9a75a4ce3e234b55e3285f1ce21fd008a02": "/36.5e2cae6657695965ac06.chunk.js",
    "4adfcf6da6cd735712a767268e9618aaf680603d": "/37.ac19e3596164eb3729fd.chunk.js",
    "db9ae2a6c57bb9395bf546abe3a9f008ab7e0358": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "12/11/2019, 11:53:32 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });